<h1 style="padding-left: 10px; color: #fff;">{{$title}}</h1>
<p style="padding-left: 10px; color: #fff;">This is the Contact page</p>
