<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
        <title><?php echo e(config('appname','AudioStar')); ?></title>
    </head>

    <div class="content">
        <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h2 style="color:white;">No song found for your search: <?php echo e($query ?? ''); ?></h2></p>
    </div>
</html>





<?php /**PATH C:\Users\Tanay\Downloads\AudioStar-master\resources\views/pages/searchnot.blade.php ENDPATH**/ ?>