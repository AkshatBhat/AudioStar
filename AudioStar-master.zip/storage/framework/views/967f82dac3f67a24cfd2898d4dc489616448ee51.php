<h1 style="padding-left: 10px; color: #fff;"><?php echo e($title); ?></h1>
<p style="padding-left: 10px; color: red;">This is the Liked Songs page</p>
<?php /**PATH C:\Users\Tanay\Downloads\AudioStar-master\resources\views/pages/likedsongs.blade.php ENDPATH**/ ?>