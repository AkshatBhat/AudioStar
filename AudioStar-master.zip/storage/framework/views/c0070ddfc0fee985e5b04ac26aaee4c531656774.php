<h1 style="padding-left: 10px; color: #fff;"><?php echo e($title); ?></h1>
<p style="padding-left: 10px; color: #fff;">This is the Contact page</p>
<?php /**PATH C:\Users\Tanay\Downloads\AudioStar-master\resources\views/pages/contact.blade.php ENDPATH**/ ?>