<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
        <title><?php echo e(config('appname','AudioStar')); ?></title>
    </head>
    <body>
        <div>
            <ul class="ulist">
                <li><img src="<?php echo e(asset('images/logo.png')); ?>" alt="main logo" height="60"></li>
                <li><a href="/">Home</a></li>
                <li><a href="/allmusic">All Music</a></li>
                <i onclick="showDropdown()" style="float: right; padding: 22px; color: #fff;" class="fa fa-ellipsis-v" id="menubutton"></i>
                <div class="container h-100">
                    <div class="d-flex justify-content-center h-100">
                        <div class="searchbar">
                            <form class="" action="<?php echo e(URL::to('/search')); ?>" method="get">
                                <div class="">
                                    <input type="text" name="query" class="search_input" placeholder="search here">
                                    <span class="">
                                        <button type="submit" name="button" class="search_icon">
                                        <span class="fa fa-search"></span>  
                                        </button>
                                    </span>
                                <div>
                            </form>
                        </div>
                    </div>
                </div>
            </ul>
            <div id="myDropdown" class="dropdown-content">
                <a href="/">Home</a>
                <a href="/about">About</a>
                <!-- <a href="/contact">Contact</a> -->
            </div>
        </div>

    <div class="sticky" id="sticky">
        <p id="np"></p>
    </div>
        
        <div class="wrapper" id="wrapper">
            <div style="padding: 10px;"></div>
            <div class="non-sticky">        
                <?php if(count($captions)>0): ?>
                    <?php $__currentLoopData = $captions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 style="padding-left: 10px; color: #fff;"><?php echo e($capt); ?></h4>
                        <div class="side-to-side">
                            
                            <?php
                                $i = 0;
                            ?>
                            <?php if($capt=='English Songs'): ?>
                                <?php $__currentLoopData = $englishsongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $es): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $i++;   
                                    ?>
                                    <div class="component" id="<?php echo e($es->id); ?>">
                                        <a href="#<?php echo e($es->id); ?>"><img src="<?php echo e($es->song_image_url); ?>" alt="<?php echo e($es->title); ?> image" height = 200 width = 200></a><br>
                                        <div style="padding: 5px;"></div>
                                        <label class="songname" for="<?php echo e($es->id); ?>">
                                            <div style="margin-bottom: 0;"><?php echo e($es->title); ?></div><div style="font-size: small; margin-top: 0;"><?php echo e($es->artist); ?></div>
                                        </label>
                                    </div>
                                    <?php
                                        if ($i==5) {
                                        break;
                                        }
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if($capt=='Hindi Songs'): ?>
                                <?php $__currentLoopData = $hindisongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $i++;   
                                    ?>
                                    <div class="component" id="<?php echo e($hs->id); ?>">
                                        <a href="#<?php echo e($hs->id); ?>"><img src="<?php echo e($hs->song_image_url); ?>" alt="<?php echo e($hs->title); ?> image" height = 200 width = 200></a><br>
                                        <div style="padding: 5px;"></div>
                                        <label class="songname" for="<?php echo e($hs->id); ?>">
                                            <div style="margin-bottom: 0;"><?php echo e($hs->title); ?></div><div style="font-size: small; margin-top: 0;"><?php echo e($hs->artist); ?></div>
                                        </label>
                                    </div>
                                    <?php
                                        if ($i==5) {
                                        break;
                                        }
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                            <?php if($capt=='Newest Releases'): ?>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $i++;   
                                    ?>
                                    <div class="component" id="<?php echo e($post->id); ?>">
                                        <a href="#<?php echo e($post->id); ?>"><img src="<?php echo e($post->song_image_url); ?>" alt="<?php echo e($post->title); ?> image" height = 200 width = 200></a><br>
                                        <div style="padding: 5px;"></div>
                                        <label class="songname" for="<?php echo e($post->id); ?>">
                                            <div style="margin-bottom: 0;"><?php echo e($post->title); ?></div><div style="font-size: small; margin-top: 0;"><?php echo e($post->artist); ?></div>
                                        </label>
                                    </div>
                                    <?php
                                        if ($i==6) {
                                        break;
                                        }
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                        </div>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <br><br><br>
        <div id="footer" class="container-audio hidden">
            <audio id="audio" controls>
                <source src="" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        </div>
    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            bindComponentClick();
        });

        function bindComponentClick() {
            $(".component").on('click', function() {
                let compId = parseInt($(this).attr("id"));
                console.log(compId);
                let songs = (<?php echo json_encode($posts->toArray(),JSON_HEX_TAG); ?>);
                console.log(songs);

                for (let i = 0; i < songs.length; i++) {
                    let obj = songs[i];
                    if (obj.id === compId) {
                        console.log(obj.song_source_url);
                        document.getElementById("sticky").style.display = "block";
                        document.getElementById("np").innerHTML = "Now playing song :"+" "+ obj.title;

                        let audio = document.getElementById("audio");
                        audio.src = obj.song_source_url;
                        $('#footer').fadeOut(function() {
                            $('#footer').addClass('hidden');
                            return 500;
                        });
                        $('#footer').fadeIn(function() {
                            $('#footer').removeClass('hidden');
                            return 500;
                        });
                        audio.play();
                        break;
                    }
                }
            });
        }
    </script>
</html> 
<?php /**PATH C:\Users\Tanay\Downloads\AudioStar-master\resources\views/posts/index.blade.php ENDPATH**/ ?>