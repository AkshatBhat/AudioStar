


<div class="wrapper">
    <div style="padding: 10px;"></div>
	<div class="non-sticky">		
        <h4 style="padding-left: 10px; color: #fff;">All Music</h4>
        <div class="side-to-side">
		
     
            <?php
                $i = 0;
            ?>
            
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $i++;	
                ?>
                <div class="component" id="<?php echo e($post->id); ?>">
					<a href="#<?php echo e($post->id); ?>"><img src="<?php echo e($post->song_image_url); ?>" alt="<?php echo e($post->title); ?> image" height = 200 width = 200></a><br>
					<div style="padding: 5px;"></div>
					<label class="songname" for="<?php echo e($post->id); ?>">
						<div style="margin-bottom: 0;"><?php echo e($post->title); ?></div><div style="font-size: small; margin-top: 0;"><?php echo e($post->artist); ?></div>
					</label>
				</div>
                <?php
                    if ($i==6) {
                        echo '</div>';
                        echo '<br>';
                        echo '<div class="side-to-side">';
                    }
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>		
	</div>
</div>
	
<script type="text/javascript">
	$(document).ready(function() {
		bindComponentClick();
	});

	function bindComponentClick() {
		$(".component").on('click', function() {
			let compId = parseInt($(this).attr("id"));
			console.log(compId);
			let songs = (<?php echo json_encode($posts->toArray(),JSON_HEX_TAG); ?>);
			console.log(songs);
			for (let i = 0; i < songs.length; i++) {
				let obj = songs[i];
				if (obj.id === compId) {
					console.log(obj.song_source_url);
					let audio = document.getElementById("audio");
					audio.src = obj.song_source_url;
					$('#footer').fadeOut(function() {
						$('#footer').addClass('hidden');
						return 500;
					});
					$('#footer').fadeIn(function() {
						$('#footer').removeClass('hidden');
						return 500;
					});
					audio.play();
					break;
				}
			}
		});
	}
</script>

<?php /**PATH C:\Users\Tanay\Downloads\AudioStar-master\resources\views/pages/allmusic.blade.php ENDPATH**/ ?>